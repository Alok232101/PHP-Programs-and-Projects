  <div class="list-group">
            <a href="index.php" class="list-group-item"><i class="fal fa-home ml-2"></i> Account </a>
            <a href="orders.php" class="list-group-item"><i class="fal fa-box-open ml-2"></i> orders</a>
            <a href="personal-detail.php" class="list-group-item"><i class="fal fa-user ml-2"></i>  Personal Details</a>
            <a href="access-detail.php" class="list-group-item"><i class="fal fa-info-circle ml-2"></i> Access Details</a>
            <a href="../sign-out.php" class="list-group-item"><i class="fal fa-sign-out ml-2"></i> Sign out</a>
         </div>