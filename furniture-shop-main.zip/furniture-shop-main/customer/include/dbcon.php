<?php 
 $host      = "localhost";
 $username  = "root";
 $passwrod  = "";
 $dbName    = "furniture-shop";

  $con = mysqli_connect($host,$username,$passwrod,$dbName);
   ?>