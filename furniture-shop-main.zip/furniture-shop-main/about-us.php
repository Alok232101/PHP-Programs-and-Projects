<?php include('include/header.php');
  ?>
  
        <div class="container sign-in-up">
          <div class="row">
            <div class="col-md-5">
             <img src="img/about-us-actor.png" width="100%">
            </div>
            <div class="col-md-7" style="height:66.5vh;">
              <h1>Online Furniture Store</h1>
              <p>
                Welcome to Online Furniture Shop, your number one source for all things.
                Online Furniture Shop Management System is a process in which we can order 
                various furniture items online. <br>
                We're dedicated to providing you the very best of product, with an emphasis
                on bed set, dining set, chairs, table, sofas, and cupboard.<br><br>
                   
                Online Furniture Shop has come a long way from its beginnings. Online Furniture Shop 
                started out for people to choose Furniture Products online at home. <br><br>
                
                We hope you enjoy our products as much as we enjoy offering them to you. If you have
                 any questions or comments, please don't hesitate to contact us.<br><br>
                  
                  
                  Sincerely,<br>
                  Online Furniture Shop Management
                
              </p>
            </div>
          </div>
        </div>
   
        <?php include('include/footer.php');?>