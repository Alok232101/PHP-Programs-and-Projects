  <!-- Sticky Footer -->
      <footer class="sticky-footer fixed-bottom">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>All &copy; Rights Resereved By Bc160402422 | <?php echo date('Y');?></span>
          </div>
        </div>
      </footer>
 
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="js/sb-admin.min.js"></script>



</body>

</html>
